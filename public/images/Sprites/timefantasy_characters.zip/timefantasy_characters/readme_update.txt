
11/7/2015 update

-------------

Hello!

I've updated the character pack to include single-frame images. The sprites in the sheets and 
the single-frames are the same graphics. The pack still includes the sprite-sheets. 


I've organized it this way for your convenience. Use whichever works best for you.

-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues