Hey thanks for buying my graphics pack!

TIME FANTASY: DWARVES VS ELVES

This character pack is compatible with all graphics in my Time Fantasy RPG style.

Create new realms for your world inhabited with elves and dwarves! 
This expansion pack includes 32 new character sprites, with walking and emotion animations. 
Sixteen elves and sixteen dwarves, with a variety of classes and archetypes for each race.

This pack also includes versions of these sprites formatted for use in RPGMaker VX/Ace and RPGMaker MV.

Have fun!

-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues