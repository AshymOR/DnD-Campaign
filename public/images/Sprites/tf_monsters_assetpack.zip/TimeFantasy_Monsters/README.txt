Thanks for buying this asset pack! :)

The graphics in this pack are compatible with all my Time Fantasy graphics (asset packs and free releases).
You can find them here: http://www.timefantasy.net

-----

This pack has two versions of the assets: regular-sized (1x) and upscaled (2x).

The upscaled version of the pack will work with the RPGMaker DLC version of Time Fantasy. If you're using a different engine, then the regular-sized sprites are probably better for you.

-----

Notes:

Since some people may be confused: The files in this pack are named so that they build on the assets in my previous TimeFantasy packs. Hence chara6, chara7, etc. I've done it this way to ensure compatability between the packs.

----

For updates, freebies, previews and more:
http://www.timefantasy.net